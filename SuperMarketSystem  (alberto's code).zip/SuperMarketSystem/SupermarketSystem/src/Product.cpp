#include "Product.h"

Product::Product()
{
    //ctor
}

Product::~Product()
{
    //dtor
}
